pelican -s setting-github.py -t bootstrap2 && firefox index.html
#pelicna-theme:https://github.com/getpelican/pelican-themes
