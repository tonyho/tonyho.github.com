Date: 2010-12-03
Title:Second time test 
Slug: test-blog
Tags: blog

Hi here is the work.

	int main()
	{
		printf("boy");
	}
